-- ============================================================
--  CicloBase — Supabase / PostgreSQL Production Schema
--  Target: Spain (ES) B2B waste marketplace
--  Roles: generator · consumer · manager · admin
--  Language: ES + CA
--  v1.0 — Full RLS policies included
-- ============================================================

-- ============================================================
-- 0. EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";        -- geolocation queries
CREATE EXTENSION IF NOT EXISTS "pg_trgm";        -- fuzzy text search
CREATE EXTENSION IF NOT EXISTS "unaccent";       -- accent-insensitive search (Spanish)

-- ============================================================
-- 1. ENUMS
-- ============================================================

CREATE TYPE user_role AS ENUM ('admin', 'company_admin', 'company_member');

CREATE TYPE company_role AS ENUM (
  'generator',   -- waste producer / seller
  'consumer',    -- material buyer
  'manager',     -- waste management company (gestor)
  'mixed'        -- both generator and consumer
);

CREATE TYPE company_size AS ENUM (
  'autonomo',    -- freelancer / self-employed
  'micro',       -- < 10 employees
  'small',       -- 10–49 employees
  'medium',      -- 50–249 employees
  'large'        -- 250+ employees
);

CREATE TYPE verification_status AS ENUM (
  'unverified',  -- just registered, no CIF provided
  'pending',     -- CIF submitted, awaiting check
  'verified',    -- CIF confirmed against AEAT
  'rejected'     -- verification failed
);

CREATE TYPE resource_type AS ENUM (
  'residuo',        -- classified waste
  'subproducto',    -- industrial by-product
  'excedente',      -- surplus production
  'equipo',         -- industrial equipment/machinery
  'donacion'        -- donation (free)
);

CREATE TYPE price_type AS ENUM (
  'fixed',          -- precio fijo
  'negotiable',     -- precio negociable
  'free',           -- gratis
  'transport_only'  -- solo coste de transporte
);

CREATE TYPE listing_status AS ENUM (
  'draft',          -- unpublished
  'active',         -- live on marketplace
  'reserved',       -- under transaction
  'sold',           -- completed
  'expired',        -- past expiry date
  'deleted'         -- soft-deleted
);

CREATE TYPE transaction_status AS ENUM (
  'inquiry',                -- initial contact / consulta
  'sample_requested',       -- buyer requested sample
  'sample_sent',            -- seller shipped sample
  'sample_received',        -- buyer confirmed receipt
  'offer_made',             -- formal offer submitted
  'offer_accepted',         -- seller accepted offer
  'offer_rejected',         -- seller rejected offer
  'payment_pending',        -- awaiting buyer payment
  'payment_escrowed',       -- funds held by platform
  'documentation_ready',    -- waste docs generated
  'pickup_scheduled',       -- transport arranged
  'in_transit',             -- goods en route
  'delivered',              -- buyer confirmed delivery
  'payment_released',       -- funds released to seller
  'impact_calculated',      -- LCA impact computed
  'completed',              -- fully closed
  'cancelled',              -- cancelled by either party
  'disputed'                -- dispute opened
);

CREATE TYPE message_type AS ENUM (
  'text',
  'offer',           -- formal price offer
  'sample_request',  -- sample request
  'system'           -- automated status update
);

CREATE TYPE habitual_treatment AS ENUM (
  'vertedero',           -- landfill
  'incineracion',        -- incineration
  'incineracion_energia',-- incineration with energy recovery
  'reciclaje',           -- recycling
  'compostaje',          -- composting
  'otro'                 -- other
);

CREATE TYPE impact_metric AS ENUM ('co2', 'water', 'energy', 'health');

CREATE TYPE plan_tier AS ENUM ('free', 'pro', 'enterprise');

-- ============================================================
-- 2. COMPANIES
-- ============================================================

CREATE TABLE companies (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                 TEXT NOT NULL,
  slug                 TEXT UNIQUE,                          -- for public profile URLs
  cif_nif              TEXT,                                 -- optional at signup
  email                TEXT NOT NULL,
  phone                TEXT,
  address              TEXT,
  city                 TEXT,
  province             TEXT,
  postal_code          TEXT,
  country              TEXT NOT NULL DEFAULT 'ES',
  -- PostGIS geolocation
  location             GEOGRAPHY(POINT, 4326),              -- for proximity queries
  location_lat         DECIMAL(10, 8),                      -- redundant for easier queries
  location_lng         DECIMAL(11, 8),
  -- Profile
  sector               TEXT,
  company_role         company_role NOT NULL DEFAULT 'mixed',
  company_size         company_size,
  logo_url             TEXT,
  cover_url            TEXT,
  description          TEXT,
  website              TEXT,
  -- Verification
  verification_status  verification_status NOT NULL DEFAULT 'unverified',
  verified_at          TIMESTAMPTZ,
  verified_by          TEXT,                                 -- admin user_id or 'auto'
  -- Plan
  plan_tier            plan_tier NOT NULL DEFAULT 'free',
  plan_started_at      TIMESTAMPTZ,
  -- Language preference
  lang_pref            TEXT NOT NULL DEFAULT 'es',          -- 'es' | 'ca'
  -- Metadata
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at           TIMESTAMPTZ                          -- soft delete
);

CREATE INDEX idx_companies_cif    ON companies(cif_nif) WHERE cif_nif IS NOT NULL;
CREATE INDEX idx_companies_role   ON companies(company_role);
CREATE INDEX idx_companies_city   ON companies(city);
CREATE INDEX idx_companies_slug   ON companies(slug);
CREATE INDEX idx_companies_loc    ON companies USING GIST(location);

-- ============================================================
-- 3. USERS
-- ============================================================

CREATE TABLE users (
  id                   UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  company_id           UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  email                TEXT NOT NULL UNIQUE,
  first_name           TEXT NOT NULL,
  last_name            TEXT NOT NULL,
  phone                TEXT,
  role                 user_role NOT NULL DEFAULT 'company_member',
  avatar_url           TEXT,
  lang_pref            TEXT NOT NULL DEFAULT 'es',
  email_verified       BOOLEAN NOT NULL DEFAULT FALSE,
  notifications_email  BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at        TIMESTAMPTZ,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_company ON users(company_id);
CREATE INDEX idx_users_email   ON users(email);

-- ============================================================
-- 4. CATEGORIES (LER-aligned, bilingual)
-- ============================================================

CREATE TABLE categories (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_es       TEXT NOT NULL,
  name_ca       TEXT NOT NULL,
  slug          TEXT NOT NULL UNIQUE,
  emoji         TEXT,
  description   TEXT,
  parent_id     UUID REFERENCES categories(id) ON DELETE SET NULL,
  ler_chapter   TEXT,          -- e.g., "12" (metalworking)
  ler_subgroup  TEXT,          -- e.g., "12 01"
  sort_order    INTEGER NOT NULL DEFAULT 0,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_categories_ler    ON categories(ler_chapter);

-- Seed top-level categories (LER chapter aligned)
INSERT INTO categories (name_es, name_ca, slug, emoji, ler_chapter, sort_order) VALUES
  ('Plásticos y cauchos',      'Plàstics i cautxús',       'plasticos-cauchos',   '♻️', '07', 1),
  ('Metales y ferrosos',        'Metalls i ferrosos',        'metales-ferrosos',    '🔩', '12', 2),
  ('Madera y derivados',        'Fusta i derivats',          'madera-derivados',    '🪵', '03', 3),
  ('Textil e indumentaria',     'Tèxtil i indumentària',     'textil',              '🧵', '04', 4),
  ('Aceites y lubricantes',     'Olis i lubricants',         'aceites-lubricantes', '🫙', '13', 5),
  ('Papel y cartón',            'Paper i cartró',            'papel-carton',        '📄', '15', 6),
  ('Construcción y minería',    'Construcció i mineria',     'construccion',        '🏗️', '17', 7),
  ('Residuos alimentarios',     'Residus alimentaris',       'alimentos',           '🌾', '02', 8),
  ('Equipos e instalaciones',   'Equips i instal·lacions',   'equipos',             '⚙️', '16', 9),
  ('Productos químicos',        'Productes químics',         'quimicos',            '⚗️', '06', 10),
  ('Vidrio y cerámica',         'Vidre i ceràmica',          'vidrio-ceramica',     '🧊', '10', 11),
  ('Lodos y biorresiduos',      'Llots i bioresidus',        'lodos-biorresiduos',  '🟫', '19', 12),
  ('Material de oficina',       'Material d\'oficina',       'oficina',             '🖨️', '16', 13),
  ('Vehículos y componentes',   'Vehicles i components',     'vehiculos',           '🚗', '16', 14),
  ('Envases y embalajes',       'Envasos i embalatges',      'envases-embalajes',   '📦', '15', 15),
  ('Otros residuos',            'Altres residus',            'otros',               '🔄', '20', 16);

-- ============================================================
-- 5. LISTINGS (Resources)
-- ============================================================

CREATE TABLE listings (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id           UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  created_by           UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  -- Identity
  title                TEXT NOT NULL,
  slug                 TEXT NOT NULL,
  description          TEXT,
  -- Classification
  category_id          UUID NOT NULL REFERENCES categories(id),
  subcategory_id       UUID REFERENCES categories(id),
  ler_code             TEXT,          -- 6-digit LER code, e.g., "12 01 03"
  resource_type        resource_type NOT NULL,
  -- Quantity
  quantity             DECIMAL(14, 3) NOT NULL,
  unit                 TEXT NOT NULL DEFAULT 'kg',    -- kg, t, l, m3, ud, m2
  quantity_available   DECIMAL(14, 3),               -- updated on partial sales
  -- Pricing
  price                DECIMAL(12, 2),
  currency             TEXT NOT NULL DEFAULT 'EUR',
  price_type           price_type NOT NULL DEFAULT 'negotiable',
  -- Physical attributes
  composition          TEXT,          -- material composition details
  purity               TEXT,          -- purity grade / calidad
  format               TEXT,          -- bales, pellets, drums, etc.
  condition            TEXT,          -- new / used / damaged
  year_manufactured    INTEGER,
  technical_specs      JSONB,         -- free-form specs for equipment
  -- Treatment
  habitual_treatment   habitual_treatment,    -- for impact calculation
  -- Location
  location             GEOGRAPHY(POINT, 4326),
  location_lat         DECIMAL(10, 8),
  location_lng         DECIMAL(11, 8),
  location_city        TEXT,
  location_province    TEXT,
  location_country     TEXT NOT NULL DEFAULT 'ES',
  pickup_only          BOOLEAN NOT NULL DEFAULT FALSE,
  -- Status and lifecycle
  status               listing_status NOT NULL DEFAULT 'draft',
  published_at         TIMESTAMPTZ,
  expires_at           TIMESTAMPTZ,
  -- Engagement
  views_count          INTEGER NOT NULL DEFAULT 0,
  inquiry_count        INTEGER NOT NULL DEFAULT 0,
  -- Search (generated column for full-text)
  search_vector        TSVECTOR GENERATED ALWAYS AS (
    setweight(to_tsvector('spanish', coalesce(title, '')), 'A') ||
    setweight(to_tsvector('spanish', coalesce(description, '')), 'B') ||
    setweight(to_tsvector('spanish', coalesce(ler_code, '')), 'C') ||
    setweight(to_tsvector('simple',  coalesce(composition, '')), 'C')
  ) STORED,
  -- Metadata
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at           TIMESTAMPTZ,
  UNIQUE(company_id, slug)
);

CREATE INDEX idx_listings_category      ON listings(category_id);
CREATE INDEX idx_listings_status        ON listings(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_listings_company       ON listings(company_id);
CREATE INDEX idx_listings_resource_type ON listings(resource_type);
CREATE INDEX idx_listings_ler           ON listings(ler_code) WHERE ler_code IS NOT NULL;
CREATE INDEX idx_listings_province      ON listings(location_province);
CREATE INDEX idx_listings_location      ON listings USING GIST(location);
CREATE INDEX idx_listings_search        ON listings USING GIN(search_vector);
CREATE INDEX idx_listings_published     ON listings(published_at DESC) WHERE status = 'active';

-- ============================================================
-- 6. LISTING PHOTOS
-- ============================================================

CREATE TABLE listing_photos (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id   UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  url          TEXT NOT NULL,
  storage_path TEXT,           -- Supabase Storage path
  alt_text     TEXT,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  is_primary   BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_listing_photos_listing ON listing_photos(listing_id);

-- ============================================================
-- 7. TRANSACTIONS
-- ============================================================

CREATE TABLE transactions (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference            TEXT UNIQUE NOT NULL,               -- human-readable: TB-2025-0001
  listing_id           UUID NOT NULL REFERENCES listings(id) ON DELETE RESTRICT,
  buyer_company_id     UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
  seller_company_id    UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
  buyer_user_id        UUID NOT NULL REFERENCES users(id)    ON DELETE RESTRICT,
  seller_user_id       UUID NOT NULL REFERENCES users(id)    ON DELETE RESTRICT,
  -- Deal terms
  status               transaction_status NOT NULL DEFAULT 'inquiry',
  quantity             DECIMAL(14, 3) NOT NULL,
  unit                 TEXT NOT NULL,
  agreed_price         DECIMAL(12, 2),
  currency             TEXT NOT NULL DEFAULT 'EUR',
  subtotal             DECIMAL(12, 2),                     -- agreed_price * quantity
  platform_fee         DECIMAL(12, 2) DEFAULT 0,           -- 0 for free tier
  total                DECIMAL(12, 2),
  -- Payment
  payment_intent_id    TEXT,                               -- Stripe PaymentIntent
  payment_method       TEXT,                               -- card, transfer, etc.
  escrowed_at          TIMESTAMPTZ,
  payment_released_at  TIMESTAMPTZ,
  -- Shipping
  shipping_address     TEXT,
  shipping_tracking    TEXT,
  pickup_scheduled_at  TIMESTAMPTZ,
  shipped_at           TIMESTAMPTZ,
  delivered_at         TIMESTAMPTZ,
  -- Integrations
  blockchain_tx_hash   TEXT,                              -- iCommunity evidence hash
  teimas_doc_ref       TEXT,                              -- Teimas documentation ref
  -- Lifecycle
  completed_at         TIMESTAMPTZ,
  cancelled_at         TIMESTAMPTZ,
  cancellation_reason  TEXT,
  cancelled_by         UUID REFERENCES users(id),
  disputed_at          TIMESTAMPTZ,
  -- Notes
  seller_notes         TEXT,
  buyer_notes          TEXT,
  -- Metadata
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_transactions_buyer    ON transactions(buyer_company_id);
CREATE INDEX idx_transactions_seller   ON transactions(seller_company_id);
CREATE INDEX idx_transactions_listing  ON transactions(listing_id);
CREATE INDEX idx_transactions_status   ON transactions(status);
CREATE INDEX idx_transactions_ref      ON transactions(reference);

-- Auto-generate reference number
CREATE SEQUENCE transactions_ref_seq START 1;
CREATE OR REPLACE FUNCTION generate_transaction_ref()
RETURNS TRIGGER AS $$
BEGIN
  NEW.reference := 'TB-' || TO_CHAR(NOW(), 'YYYY') || '-' || LPAD(nextval('transactions_ref_seq')::TEXT, 4, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_transaction_ref
  BEFORE INSERT ON transactions
  FOR EACH ROW EXECUTE FUNCTION generate_transaction_ref();

-- ============================================================
-- 8. TRANSACTION STATUS LOG (audit trail)
-- ============================================================

CREATE TABLE transaction_status_log (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id    UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  from_status       transaction_status,
  to_status         transaction_status NOT NULL,
  changed_by        UUID REFERENCES users(id),
  changed_by_role   TEXT,             -- 'buyer', 'seller', 'admin', 'system'
  notes             TEXT,
  metadata          JSONB,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_status_log_tx ON transaction_status_log(transaction_id);

-- Auto-log status changes
CREATE OR REPLACE FUNCTION log_transaction_status()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO transaction_status_log(transaction_id, from_status, to_status, changed_by_role)
    VALUES (NEW.id, OLD.status, NEW.status, 'system');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tx_status_log
  AFTER UPDATE ON transactions
  FOR EACH ROW EXECUTE FUNCTION log_transaction_status();

-- ============================================================
-- 9. SAMPLE REQUESTS
-- ============================================================

CREATE TABLE sample_requests (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id            UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  requester_company_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  requester_user_id     UUID NOT NULL REFERENCES users(id),
  status                TEXT NOT NULL DEFAULT 'pending',
                        -- pending | approved | denied | shipped | received | rejected
  quantity_requested    DECIMAL(8, 3),
  unit                  TEXT DEFAULT 'kg',
  shipping_name         TEXT,
  shipping_address      TEXT,
  shipping_city         TEXT,
  shipping_postal_code  TEXT,
  notes                 TEXT,
  tracking_number       TEXT,
  shipped_at            TIMESTAMPTZ,
  received_at           TIMESTAMPTZ,
  decision_at           TIMESTAMPTZ,
  decision_by           UUID REFERENCES users(id),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_samples_listing   ON sample_requests(listing_id);
CREATE INDEX idx_samples_requester ON sample_requests(requester_company_id);

-- ============================================================
-- 10. CONVERSATIONS AND MESSAGES
-- ============================================================

CREATE TABLE conversations (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id            UUID REFERENCES listings(id) ON DELETE SET NULL,
  transaction_id        UUID REFERENCES transactions(id) ON DELETE SET NULL,
  company_a_id          UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  company_b_id          UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  last_message_at       TIMESTAMPTZ,
  last_message_preview  TEXT,
  unread_count_a        INTEGER NOT NULL DEFAULT 0,   -- unread for company_a
  unread_count_b        INTEGER NOT NULL DEFAULT 0,   -- unread for company_b
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_conversations_company_a ON conversations(company_a_id);
CREATE INDEX idx_conversations_company_b ON conversations(company_b_id);
CREATE INDEX idx_conversations_last_msg  ON conversations(last_message_at DESC);

CREATE TABLE messages (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id  UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id        UUID NOT NULL REFERENCES users(id),
  sender_company   UUID NOT NULL REFERENCES companies(id),
  message_type     message_type NOT NULL DEFAULT 'text',
  content          TEXT NOT NULL,
  metadata         JSONB,            -- { price, quantity } for offers; { address } for samples
  is_read          BOOLEAN NOT NULL DEFAULT FALSE,
  read_at          TIMESTAMPTZ,
  deleted_at       TIMESTAMPTZ,      -- soft delete
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id);
CREATE INDEX idx_messages_sender       ON messages(sender_id);
CREATE INDEX idx_messages_created      ON messages(created_at DESC);

-- Update conversation on new message
CREATE OR REPLACE FUNCTION update_conversation_on_message()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE conversations SET
    last_message_at      = NEW.created_at,
    last_message_preview = LEFT(NEW.content, 80),
    unread_count_a       = CASE WHEN NEW.sender_company != company_a_id THEN unread_count_a + 1 ELSE 0 END,
    unread_count_b       = CASE WHEN NEW.sender_company != company_b_id THEN unread_count_b + 1 ELSE 0 END
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_conversation
  AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION update_conversation_on_message();

-- ============================================================
-- 11. IMPACT RECORDS
-- ============================================================

CREATE TABLE impact_records (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id       UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  company_id           UUID NOT NULL REFERENCES companies(id),
  listing_id           UUID NOT NULL REFERENCES listings(id),
  category_id          UUID NOT NULL REFERENCES categories(id),
  -- Calculation inputs
  quantity_kg          DECIMAL(14, 3) NOT NULL,
  habitual_treatment   habitual_treatment NOT NULL,
  -- Results (4 ACV indicators)
  co2_avoided_kg       DECIMAL(16, 6),     -- kg CO₂ equivalent (ReCiPe 2016)
  water_saved_liters   DECIMAL(16, 4),     -- litres (AWARE v1.01)
  energy_saved_mj      DECIMAL(16, 4),     -- MJ (CED v1.10)
  health_daly_avoided  DECIMAL(16, 10),    -- DALY (ReCiPe 2016 Endpoint)
  -- Equivalences (for UI display)
  co2_equiv_car_km     DECIMAL(12, 2),     -- CO₂ in equivalent car km
  co2_equiv_trees      DECIMAL(12, 2),     -- CO₂ in trees planted
  water_equiv_showers  DECIMAL(12, 2),
  -- Methodology
  methodology_version  TEXT NOT NULL DEFAULT 'v1.0',
  lca_software         TEXT DEFAULT 'CicloBase ACV Engine',
  databases_used       TEXT[] DEFAULT ARRAY['ecoinvent 3.9', 'ELCD'],
  -- Report
  report_pdf_url       TEXT,
  report_storage_path  TEXT,
  -- Audit
  verified_by          TEXT,             -- e.g., 'pending', 'third-party-name'
  calculated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_impact_company     ON impact_records(company_id);
CREATE INDEX idx_impact_transaction ON impact_records(transaction_id);
CREATE INDEX idx_impact_calculated  ON impact_records(calculated_at DESC);

-- View: aggregated company impact
CREATE VIEW company_impact_summary AS
SELECT
  company_id,
  COUNT(*)                              AS total_transactions,
  SUM(quantity_kg)                      AS total_kg_valorized,
  SUM(co2_avoided_kg) / 1000           AS co2_avoided_tonnes,
  SUM(water_saved_liters)              AS water_saved_liters,
  SUM(energy_saved_mj)                 AS energy_saved_mj,
  SUM(health_daly_avoided)             AS daly_avoided,
  MIN(calculated_at)                   AS first_impact,
  MAX(calculated_at)                   AS last_impact
FROM impact_records
GROUP BY company_id;

-- ============================================================
-- 12. IMPACT FACTOR LOOKUP (ACV per category × treatment)
-- ============================================================

CREATE TABLE impact_factors (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id           UUID NOT NULL REFERENCES categories(id),
  treatment             habitual_treatment NOT NULL,
  -- CO₂ factors (kg CO₂ avoided per kg material)
  co2_factor_kg_per_kg  DECIMAL(10, 6) NOT NULL DEFAULT 0,
  -- Water factor (L saved per kg material)
  water_factor_l_per_kg DECIMAL(12, 4) NOT NULL DEFAULT 0,
  -- Energy factor (MJ saved per kg material)
  energy_factor_mj_per_kg DECIMAL(12, 4) NOT NULL DEFAULT 0,
  -- Health factor (DALY avoided per kg material)
  daly_factor_per_kg    DECIMAL(14, 10) NOT NULL DEFAULT 0,
  -- Source references
  source                TEXT,
  methodology_version   TEXT NOT NULL DEFAULT 'v1.0',
  valid_from            DATE NOT NULL DEFAULT CURRENT_DATE,
  valid_to              DATE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(category_id, treatment, valid_from)
);

-- ============================================================
-- 13. NOTIFICATIONS
-- ============================================================

CREATE TABLE notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  type        TEXT NOT NULL,      -- 'new_message','new_offer','sample_request','tx_update','match_found'
  title       TEXT NOT NULL,
  body        TEXT,
  metadata    JSONB,              -- { transaction_id, listing_id, etc. }
  is_read     BOOLEAN NOT NULL DEFAULT FALSE,
  read_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user    ON notifications(user_id);
CREATE INDEX idx_notifications_unread  ON notifications(user_id) WHERE is_read = FALSE;

-- ============================================================
-- 14. AI MATCH SUGGESTIONS
-- ============================================================

CREATE TABLE ai_matches (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id        UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  matched_company   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  match_score       DECIMAL(5, 4),     -- 0.0 to 1.0
  match_reasons     TEXT[],            -- ['same_category','same_province','matching_volume']
  notified_at       TIMESTAMPTZ,
  viewed_at         TIMESTAMPTZ,
  contacted_at      TIMESTAMPTZ,
  dismissed         BOOLEAN NOT NULL DEFAULT FALSE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(listing_id, matched_company)
);

CREATE INDEX idx_ai_matches_listing ON ai_matches(listing_id);
CREATE INDEX idx_ai_matches_company ON ai_matches(matched_company);

-- ============================================================
-- 15. COMPANY CERTIFICATIONS
-- ============================================================

CREATE TABLE company_certifications (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  cert_type     TEXT NOT NULL,       -- 'ISO14001', 'ISO9001', 'EMAS', 'REI', 'gestor_autorizado'
  cert_number   TEXT,
  issuer        TEXT,
  issued_at     DATE,
  expires_at    DATE,
  document_url  TEXT,
  verified      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_certifications_company ON company_certifications(company_id);

-- ============================================================
-- 16. ADMIN / MODERATION
-- ============================================================

CREATE TABLE moderation_flags (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  flagged_by      UUID REFERENCES users(id),
  entity_type     TEXT NOT NULL,    -- 'listing' | 'company' | 'message'
  entity_id       UUID NOT NULL,
  reason          TEXT NOT NULL,
  details         TEXT,
  status          TEXT NOT NULL DEFAULT 'pending',  -- pending | reviewed | dismissed | actioned
  reviewed_by     UUID REFERENCES users(id),
  reviewed_at     TIMESTAMPTZ,
  action_taken    TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- 17. UPDATED_AT TRIGGERS
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_companies_updated_at   BEFORE UPDATE ON companies   FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_users_updated_at       BEFORE UPDATE ON users       FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_listings_updated_at    BEFORE UPDATE ON listings    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_transactions_updated_at BEFORE UPDATE ON transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_samples_updated_at     BEFORE UPDATE ON sample_requests FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- 18. ROW LEVEL SECURITY (RLS)
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE companies             ENABLE ROW LEVEL SECURITY;
ALTER TABLE users                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE listings              ENABLE ROW LEVEL SECURITY;
ALTER TABLE listing_photos        ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions          ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaction_status_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE sample_requests       ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations         ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages              ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact_records        ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications         ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_matches            ENABLE ROW LEVEL SECURITY;

-- ────────────────────────────────────────────
-- Helper: get current user's company_id
-- ────────────────────────────────────────────
CREATE OR REPLACE FUNCTION my_company_id()
RETURNS UUID AS $$
  SELECT company_id FROM users WHERE id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Helper: check if current user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
  SELECT EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ────────────────────────────────────────────
-- COMPANIES
-- ────────────────────────────────────────────
-- Public: anyone can view verified companies
CREATE POLICY "companies_public_read" ON companies
  FOR SELECT USING (
    verification_status IN ('verified', 'pending') AND deleted_at IS NULL
  );

-- Members: can view their own company regardless of status
CREATE POLICY "companies_own_read" ON companies
  FOR SELECT USING (id = my_company_id());

-- Admins: full access
CREATE POLICY "companies_admin_all" ON companies
  FOR ALL USING (is_admin());

-- Members: company_admin can update their company
CREATE POLICY "companies_admin_update" ON companies
  FOR UPDATE USING (
    id = my_company_id() AND
    EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('admin', 'company_admin'))
  );

-- ────────────────────────────────────────────
-- USERS
-- ────────────────────────────────────────────
-- Users can read others in same company
CREATE POLICY "users_same_company_read" ON users
  FOR SELECT USING (company_id = my_company_id());

-- Users can only update themselves
CREATE POLICY "users_self_update" ON users
  FOR UPDATE USING (id = auth.uid());

-- Company admins can read all users in their company
CREATE POLICY "users_company_admin_read" ON users
  FOR SELECT USING (
    company_id = my_company_id() AND
    EXISTS(SELECT 1 FROM users u2 WHERE u2.id = auth.uid() AND u2.role IN ('admin','company_admin'))
  );

-- Admins: full access
CREATE POLICY "users_admin_all" ON users
  FOR ALL USING (is_admin());

-- ────────────────────────────────────────────
-- LISTINGS
-- ────────────────────────────────────────────
-- Public: anyone can view active listings
CREATE POLICY "listings_public_read" ON listings
  FOR SELECT USING (
    status = 'active' AND deleted_at IS NULL
  );

-- Owners: can view all their own listings (incl. drafts)
CREATE POLICY "listings_own_all" ON listings
  FOR ALL USING (company_id = my_company_id());

-- Admins: full access
CREATE POLICY "listings_admin_all" ON listings
  FOR ALL USING (is_admin());

-- ────────────────────────────────────────────
-- LISTING PHOTOS
-- ────────────────────────────────────────────
CREATE POLICY "photos_public_read" ON listing_photos
  FOR SELECT USING (
    EXISTS(SELECT 1 FROM listings l WHERE l.id = listing_id AND l.status = 'active')
  );

CREATE POLICY "photos_owner_all" ON listing_photos
  FOR ALL USING (
    EXISTS(SELECT 1 FROM listings l WHERE l.id = listing_id AND l.company_id = my_company_id())
  );

-- ────────────────────────────────────────────
-- TRANSACTIONS
-- ────────────────────────────────────────────
-- Only buyer or seller can see their transactions
CREATE POLICY "transactions_participants" ON transactions
  FOR SELECT USING (
    buyer_company_id  = my_company_id() OR
    seller_company_id = my_company_id()
  );

CREATE POLICY "transactions_participants_update" ON transactions
  FOR UPDATE USING (
    buyer_company_id  = my_company_id() OR
    seller_company_id = my_company_id()
  );

CREATE POLICY "transactions_insert" ON transactions
  FOR INSERT WITH CHECK (
    buyer_company_id = my_company_id()
  );

CREATE POLICY "transactions_admin" ON transactions
  FOR ALL USING (is_admin());

-- ────────────────────────────────────────────
-- TRANSACTION STATUS LOG
-- ────────────────────────────────────────────
CREATE POLICY "status_log_participants" ON transaction_status_log
  FOR SELECT USING (
    EXISTS(
      SELECT 1 FROM transactions t
      WHERE t.id = transaction_id AND (
        t.buyer_company_id  = my_company_id() OR
        t.seller_company_id = my_company_id()
      )
    )
  );

-- ────────────────────────────────────────────
-- SAMPLE REQUESTS
-- ────────────────────────────────────────────
-- Requester can see their own
CREATE POLICY "samples_requester_read" ON sample_requests
  FOR SELECT USING (requester_company_id = my_company_id());

-- Listing owner can see all samples for their listings
CREATE POLICY "samples_listing_owner" ON sample_requests
  FOR SELECT USING (
    EXISTS(
      SELECT 1 FROM listings l
      WHERE l.id = listing_id AND l.company_id = my_company_id()
    )
  );

-- Requester can create
CREATE POLICY "samples_insert" ON sample_requests
  FOR INSERT WITH CHECK (requester_company_id = my_company_id());

-- Listing owner can update (approve/deny)
CREATE POLICY "samples_listing_owner_update" ON sample_requests
  FOR UPDATE USING (
    EXISTS(
      SELECT 1 FROM listings l
      WHERE l.id = listing_id AND l.company_id = my_company_id()
    )
  );

-- ────────────────────────────────────────────
-- CONVERSATIONS & MESSAGES
-- ────────────────────────────────────────────
CREATE POLICY "conversations_participants" ON conversations
  FOR SELECT USING (
    company_a_id = my_company_id() OR
    company_b_id = my_company_id()
  );

CREATE POLICY "conversations_create" ON conversations
  FOR INSERT WITH CHECK (
    company_a_id = my_company_id()
  );

CREATE POLICY "messages_participants" ON messages
  FOR SELECT USING (
    EXISTS(
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_id AND (
        c.company_a_id = my_company_id() OR
        c.company_b_id = my_company_id()
      )
    )
  );

CREATE POLICY "messages_sender" ON messages
  FOR INSERT WITH CHECK (sender_company = my_company_id());

-- ────────────────────────────────────────────
-- IMPACT RECORDS
-- ────────────────────────────────────────────
-- Participants can see their impact records
CREATE POLICY "impact_participants" ON impact_records
  FOR SELECT USING (company_id = my_company_id());

-- Platform auto-inserts impact records (via service role)
CREATE POLICY "impact_service_insert" ON impact_records
  FOR INSERT WITH CHECK (TRUE);  -- restricted to service_role key in practice

-- ────────────────────────────────────────────
-- NOTIFICATIONS
-- ────────────────────────────────────────────
CREATE POLICY "notifications_own" ON notifications
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "notifications_mark_read" ON notifications
  FOR UPDATE USING (user_id = auth.uid());

-- ────────────────────────────────────────────
-- AI MATCHES
-- ────────────────────────────────────────────
CREATE POLICY "matches_listing_owner" ON ai_matches
  FOR SELECT USING (
    EXISTS(
      SELECT 1 FROM listings l
      WHERE l.id = listing_id AND l.company_id = my_company_id()
    )
  );

CREATE POLICY "matches_target_company" ON ai_matches
  FOR SELECT USING (matched_company = my_company_id());

-- ============================================================
-- 19. USEFUL VIEWS
-- ============================================================

-- Public marketplace view (safe for anon)
CREATE VIEW public_listings AS
SELECT
  l.id, l.title, l.slug, l.description,
  l.category_id, l.subcategory_id, l.ler_code,
  l.resource_type, l.quantity, l.unit,
  l.price, l.currency, l.price_type,
  l.location_city, l.location_province, l.location_country,
  l.location_lat, l.location_lng,
  l.views_count, l.inquiry_count,
  l.published_at,
  c.id AS company_id,
  c.name AS company_name,
  c.verification_status AS company_verified,
  c.company_size,
  cat.name_es AS category_name_es,
  cat.name_ca AS category_name_ca,
  cat.emoji AS category_emoji,
  (SELECT url FROM listing_photos p WHERE p.listing_id = l.id AND p.is_primary ORDER BY p.sort_order LIMIT 1) AS primary_photo
FROM listings l
JOIN companies c ON c.id = l.company_id
JOIN categories cat ON cat.id = l.category_id
WHERE l.status = 'active' AND l.deleted_at IS NULL AND c.deleted_at IS NULL;

-- Dashboard summary for authenticated company
CREATE VIEW company_dashboard AS
SELECT
  c.id AS company_id,
  c.name,
  c.plan_tier,
  c.verification_status,
  -- Listings
  COUNT(DISTINCT l.id) FILTER (WHERE l.status = 'active')  AS active_listings,
  COUNT(DISTINCT l.id) FILTER (WHERE l.status = 'draft')   AS draft_listings,
  -- Transactions
  COUNT(DISTINCT t.id) FILTER (WHERE t.status NOT IN ('completed','cancelled') AND (t.buyer_company_id = c.id OR t.seller_company_id = c.id)) AS open_transactions,
  COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'completed' AND (t.buyer_company_id = c.id OR t.seller_company_id = c.id)) AS completed_transactions,
  -- Impact
  COALESCE(SUM(ir.co2_avoided_kg) / 1000, 0)    AS co2_avoided_tonnes,
  COALESCE(SUM(ir.water_saved_liters), 0)        AS water_saved_liters,
  COALESCE(SUM(ir.energy_saved_mj), 0)           AS energy_saved_mj,
  -- Unread messages
  COUNT(DISTINCT msg.id) FILTER (WHERE msg.is_read = FALSE AND msg.sender_company != c.id) AS unread_messages
FROM companies c
LEFT JOIN listings l ON l.company_id = c.id AND l.deleted_at IS NULL
LEFT JOIN transactions t ON (t.buyer_company_id = c.id OR t.seller_company_id = c.id)
LEFT JOIN impact_records ir ON ir.company_id = c.id
LEFT JOIN conversations conv ON (conv.company_a_id = c.id OR conv.company_b_id = c.id)
LEFT JOIN messages msg ON msg.conversation_id = conv.id
GROUP BY c.id, c.name, c.plan_tier, c.verification_status;

-- ============================================================
-- 20. STORAGE BUCKETS (Supabase Storage — run in Dashboard)
-- ============================================================
-- Run these in the Supabase Storage settings, not SQL:
--
-- CREATE BUCKET 'listing-photos'   (public: true,  file_size_limit: 5MB, allowed_types: ['image/*'])
-- CREATE BUCKET 'company-logos'    (public: true,  file_size_limit: 2MB, allowed_types: ['image/*'])
-- CREATE BUCKET 'impact-reports'   (public: false, file_size_limit: 20MB, allowed_types: ['application/pdf'])
-- CREATE BUCKET 'certifications'   (public: false, file_size_limit: 10MB, allowed_types: ['application/pdf','image/*'])

-- ============================================================
-- 21. SUPABASE REALTIME (enable in Dashboard)
-- ============================================================
-- Enable realtime on:
--   messages            → for live chat
--   notifications       → for live notification bell
--   transactions        → for live status updates
--   transaction_status_log → for timeline updates

-- ============================================================
-- 22. EDGE FUNCTIONS (deploy separately)
-- ============================================================
-- /calculate-impact   → POST { listing_id, quantity, treatment } → inserts impact_record
-- /generate-pdf       → POST { transaction_id } → generates PDF, uploads to Storage
-- /send-notification  → POST { user_id, type, metadata } → email + in-app
-- /stripe-webhook     → handles Stripe payment events, updates transaction status
-- /ai-match           → triggered on listing INSERT, populates ai_matches table
-- /verify-cif         → validates CIF/NIF format and updates verification_status

-- ============================================================
-- DONE — CicloBase v1.0 Production Schema
-- ============================================================
